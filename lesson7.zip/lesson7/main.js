(function ($) {

	var material, product;

	material = ['heavy', 'weightless', 'liquid', 'reflective', 'corrosive', 'flexible', 'malleable', 'stiff', 'flammable', 'fabric', 'styrofoam', 'Vinyl', 'felt', 'wool', 'ceramic', 'plastic', 'aluminum', 'steel', 'cast', 'digital', 'paper', 'cardboard', 'maple', 'walnut', 'ceramic', 'glass', 'gold', 'silver', 'bronze', 'brass', 'copper', 'carbon', 'cotton', 'printed', 'rubber', 'silicone', 'canvas', 'concrete', 'stone', 'rope', 'wire', 'plywood', 'hair', "brick", "leather", "suede", "3d", "cork", "foam", "putty", "hemp", "bamboo", "dirt", "twig", "sheet", "stone", "metal", "wrought", "nickel", "tin", "zinc", "balsa", "oak", "teak", "bone", "ivory", "rattan", "diamond", "charcoal", "plaster", "clay", "feather", "floor", "ceiling", "wall", "corner", "papier", "nylon", "mercury", "marble", "corian", "glowing", "floating", "magnetic", "fiber", "foil", "porcelain", "wax", "underwater", "outerspace", "outdoor"];

	product = [
		['phone',['phone-and-accessories']], 
		['headphones',['phone-and-accessories']], 
		['tivi',['electronics']], 
		['gel',['health-and-beauty','sport-and-fitness']],
		['ball',['sport-and-fitness']],
		['tool',['home-and-garden','electronics']],
		['wheel',['home-and-garden']],
		['cable',['electronics']],
		['t-shirt',['fashion']],
		['ring',['fashion']],
		['mouse',['electronics']],
		['keyboard',['electronics']],
		['scissors',['home-and-garden']],
		['cream',['sport-and-fitness','health-and-beauty']],
		['goggles',['sport-and-fitness','fashion']]
	];

	brand = ['apple','philip','samsung','nokia','xiaomi'];

	char = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

	function create_product() {
		var name = '',
			product_item = random_array(product),
			price;
		for (i = 0; i <= Math.random() * 2;i++){
			name += random_array(material) + ' ';
		}
		name += product_item[0] + ' ' + random_array(char) + random_array(char) + '-';
		name += Math.floor(Math.random() * 900 + 10).toString();
		if (Math.floor(Math.random() * 2)){
			var min = Math.floor(Math.random() * 1500),
				max = Math.min(Math.floor(Math.random() * 400 + 10) + min,1600);
			price = {
				min: min,
				max: max
			}
		}else{
			price = Math.floor(Math.random() * 1591 + 10)
		}
		return {
			name : name,
			categories: product_item[1],
			price: price,
			brand: random_array(brand),
			image: 'assets/images/product/new/' + product_item[0] + '-' + Math.floor(Math.random() * 3 + 1).toString() + '.jpg'
		};
	}

	function random_array(array){
		return array[Math.floor(Math.random() * array.length)]
	}

	var products = [];
	var counter = 0;
	for (counter = 0; counter < 10; counter++) {
		//console.log(counter);
		products.push(create_product());
	}
	console.log(JSON.stringify(products))


})(jQuery);