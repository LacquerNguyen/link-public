(function ($) {
    function read_data(){
        $.ajax({
            url: '/data.json',
            type: "get",
            dataType: "json",
            success: function (data) {
                console.log(data)
                    render(data)
        
            }
        });
    }
        function pagination(sta,limit){
            var sta = 0;
            var end= 3;
            var limit = elements_per_page;
            for (let i = sta; i < end; i++) {
                var html = '<li class="shop__product col-md-4 col-xs-6">'+
                    '<a href="#">'+
                        '<p class="shop__product_img">'+'<img src="'+ items.image +'" alt="" /></p>'+
                        '<h3 class="shop__product_name">'+items.name +'</h3>'+
                        '<span class="from">'+'<strong class="price">'+items.price+'$'+'</strong></span>'+
                        '<span class="shop__btn_view_offer">view offers</span>'+
                ' </a>'+
                '</li>'
             $('.shop__product_list').append(html)
            }
        }
        function render(data){ 
            var number = Math.round(data.length / 3);
            for(i=0;i<=number;i++) {
                $('.nav').append('<button class="btn">'+i+'</button>');
            }
            $('.nav button').click(function(){
                var start = $(this).text();
                console.log(start)
                table.empty();
                limit = 3*(parseInt(start)+1) > data ? data: 3*(parseInt(start)+1)
                goFun(start*3,limit); 
                });
        }

    read_data()
	
})(jQuery);