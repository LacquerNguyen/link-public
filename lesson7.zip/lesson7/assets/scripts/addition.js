(function ($) {

	$('.custom__select_text_wrap').each(function(){
		var _this = $(this),
			select = _this.find('.select'),
			text = _this.find('.text');
		text.text(select.find('option[value="' + select.val() + '"]').text());
		select.on('change',function(){
			text.text(select.find('option[value="' + select.val() + '"]').text());
		});
	});

	if ($('.shop__filter_ranger_slider').length){
		var slider = $('.shop__filter_ranger_slider');
		slider.each(function(){
			var _this = $(this);
			noUiSlider.create(_this[0], {
				start: [_this.data('start'),_this.data('end')],
				connect: true,
				range: {
					'min': _this.data('min'),
					'max': _this.data('max')
				}
			}).on('update',function(values,handle){
				var range_price = _this.parent().find('.shop__filter_ranger_price');
				if (range_price.length){
					range_price.find('.min .num').text(parseFloat(values[0]).toFixed(1));
					range_price.find('.max .num').text(parseFloat(values[1]).toFixed(1));
					$('#shop-min-price').val(parseFloat(values[0]).toFixed(1));
					$('#shop-max-price').val(parseFloat(values[1]).toFixed(1));
					$('#shop-min-price').trigger('change');
					$('#shop-max-price').trigger('change');
				}
			})
		});
	}

})(jQuery);